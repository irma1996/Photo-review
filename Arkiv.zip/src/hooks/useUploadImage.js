import { useState, useEffect } from 'react';
import { db, storage } from  '../firebase';
import {useAuth} from '../contexts/AuthContext'
		
    const useUploadImage = (image, albumId = null) => {
    const [uploadProgress, setUploadProgress] = useState(null);
    const [uploadedImage, setUploadedImage] = useState(null); 
    const [error, setError] = useState(null);
    const [isSuccess, setIsSuccess] = useState(false);
    const {currentUser} = useAuth()

    useEffect(()=>{
		if(!image){
			setUploadProgress(null);
			setUploadedImage(null);
			setError(null);
			setIsSuccess(false);

			return;
		}

		//reset enviroment
		setError(null);
		setIsSuccess(false);
	

		// get file reference
		const fileRef = storage.ref(`images/${currentUser.uid}/${image.name}`);


		// put file to fileRef
		const uploadTask = fileRef.put(image);

		//atach listener for `state_changed-event
		uploadTask.on('state_changed', taskSnapshot => {
			setUploadProgress(Math.round((taskSnapshot.bytesTransferred / taskSnapshot.totalBytes) * 100));
			//console.log(`Transfered ${taskSnapshot.bytesTransferred} bytes out of ${taskSnapshot.totalBytes} which is ${progress} %.`);
		});
		

		// are we there yet?
		uploadTask.then(async snapshot=>{		
			//rereieve URL to uploaded file
			const url = await snapshot.ref.getDownloadURL();
             //add uploaded file to db
             const img ={
				name: image.name,
				owner: currentUser.uid,
				path: snapshot.ref.fullPath,
				size: image.size,
				type:image.type,
				url,		
             };
	
			//get docref to album
			 if(albumId){
			 	img.album = db.collection('albums').doc(albumId) 
			 }

			
			await db.collection('images').add(img) 
			
				//let user know we are done
				setIsSuccess(true);
				setUploadProgress(null);
					
				//image hase been added to db
                 setUploadedImage(img);
                 setIsSuccess(true);

	
		}).catch(error => {
			console.error("image upload can been uploadded!", error);
            setError({
				typ: "warning",
				msg: `Image could not be uploaded (${error.code})`
			});
		});		
    }, [image, albumId, currentUser]);

    return {uploadProgress, uploadedImage, error, isSuccess};
}
 
export default useUploadImage;
