import { createContext, useContext, useState, useEffect } from "react";
import {auth} from '../firebase'

export const AuthContext = createContext();

export const useAuth = () => {
    return useContext(AuthContext);
  };
  

const AuthContextProvider = (props) => {
    const [ currentUser, setCurrentUser] = useState(null);
    const [loadingPage, setLoading] = useState(true)

    const login = (email,password) => {
      return auth.signInWithEmailAndPassword(email,password)  
    }

    const logout = () => {
        setCurrentUser(null);
        return auth.signOut()
    }

    const resetPassword = (email) => {
        return auth.sendPasswordResetEmail(email)
    }

    const signup = (email, password) => {
        //sign up
        return auth.createUserWithEmailAndPassword(email, password)
    }

    // const updateEmail = (email) => {
    //     return currentUser.updateEmail( email)
    // }

    // const updatePassword = (password) =>{
    //     return currentUser.updatePassword(password)
    // }

    // const updateProfile = (name) => {
    //     return currentUser.updateProfile({ 
    //         displayName: name 
    //     })
    // }

    useEffect(() => { 
       const unsubcribe = auth.onAuthStateChanged(user => {
          setCurrentUser(user)
          setLoading(false) 
        }); 
        
        return unsubcribe;
    },[])

    const contextValues = {
        loadingPage,
        login,
        logout,
        resetPassword,
        signup,
        currentUser,
 
       
        // updateEmail,
        // updatePassword,
        // updateProfile,
    }

    return(
        <AuthContext.Provider value={contextValues}>
            {loadingPage && <p>LOADING...</p>}
            {!loadingPage && props.children}
        </AuthContext.Provider>
    )
}


export default  AuthContextProvider;
