import React from 'react'

function NotFound() {
    return (
        <div>
                <pre>404 Page is misssing </pre>
        </div>
    )
}

export default NotFound
